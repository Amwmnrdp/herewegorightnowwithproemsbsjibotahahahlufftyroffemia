[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Replace the website code in the public folder
[x] 4. Verify the project is working and the bot is online
[x] 5. Inform user the import is completed and they can start building
[x] 6. Clean and set up new website files in public folder
[x] 7. Delete tree and temporary folders
[x] 8. Explain watermark and domain policies to user
[x] 9. Fix dashboard stats fetching error